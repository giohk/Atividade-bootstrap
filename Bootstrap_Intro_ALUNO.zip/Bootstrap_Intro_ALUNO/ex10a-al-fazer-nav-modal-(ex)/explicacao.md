# Mini Exercício 10a: Formulário de Contato com Modal

## Objetivo  
Criar um formulário de contato dentro de um modal, acionado por um botão dentro da navbar.

## Instruções

1. Adicione um **botão "Contato"** na navbar que abre um modal quando clicado.
2. Dentro do modal, insira um **formulário** com os campos:
   - **Nome**
   - **E-mail**
   - **Mensagem**
3. Utilize a **validação do Bootstrap** para garantir que os campos sejam preenchidos corretamente.
