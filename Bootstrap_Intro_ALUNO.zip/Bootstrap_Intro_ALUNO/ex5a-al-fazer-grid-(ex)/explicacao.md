# Exercício 5a: Criando um Layout com Grid e Cards

## Enunciado

Crie uma página HTML que utilize o sistema de grid do Bootstrap para organizar três cards em uma linha.  

Cada card deve conter:
- Um título  
- Um texto descritivo  
- Um botão  

Utilize as classes do Bootstrap para garantir que os cards fiquem alinhados e responsivos.  

O layout deve se ajustar para dispositivos móveis, exibindo os cards em uma única coluna.
