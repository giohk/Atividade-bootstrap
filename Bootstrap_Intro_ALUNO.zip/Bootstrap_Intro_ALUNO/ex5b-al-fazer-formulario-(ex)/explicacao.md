# Exercício 5b: Formulário Moderno e Minimalista

## Enunciado

Crie um formulário de login com um design moderno e minimalista.  

O formulário deve conter:

- Um campo de email com um ícone de envelope (`bi-envelope`).  
- Um campo de senha com um ícone de cadeado (`bi-lock`).  
- Um botão de submit com um ícone de seta (`bi-arrow-right`).  

Utilize cores suaves, bordas arredondadas e transições suaves para os inputs e botão.
